package com.example.project;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.SlidingDrawer;
import android.widget.Spinner;

public class MainActivity extends Activity {
	private Spinner spnMaterial;
	String[] Material = new String[] {"����", "a", "b"};
	
	private SlidingDrawer sd_top;
	private SlidingDrawer sd_right;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		/* ��P�}�� */
		slidingOC();
		
		/* �U�Ԧ��M�椺�e */
		spnMaterial = (Spinner) findViewById(R.id.spnMaterial);
		ArrayAdapter<String> adapterMaterial = new ArrayAdapter<String>
		  (this, android.R.layout.simple_spinner_item, Material);
		adapterMaterial.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spnMaterial.setAdapter(adapterMaterial);
	}
	
	private void slidingOC(){
		sd_top = (SlidingDrawer) findViewById(R.id.sd_top);
		sd_right = (SlidingDrawer) findViewById(R.id.sd_right);
		
		/* �]�wSlidingDrawer_Top���}������SlidingDrawer_Right */ 
		sd_top.setOnDrawerOpenListener
		(new SlidingDrawer.OnDrawerOpenListener(){ 
			@Override 
			public void onDrawerOpened(){
				if(sd_right.isOpened())
					sd_right.animateClose();
			} 
		}); 
		
		/* �]�wSlidingDrawer_Right���}������SlidingDrawer_Top */ 
		sd_right.setOnDrawerOpenListener
		(new SlidingDrawer.OnDrawerOpenListener(){ 
			@Override 
			public void onDrawerOpened(){
				if(sd_top.isOpened())
					sd_top.animateClose();
			} 
		}); 
	}
	
}
